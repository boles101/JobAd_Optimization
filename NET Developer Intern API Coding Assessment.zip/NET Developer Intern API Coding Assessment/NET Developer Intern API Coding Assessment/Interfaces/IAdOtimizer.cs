﻿using NET_Developer_Intern_API_Coding_Assessment.Model;

namespace NET_Developer_Intern_API_Coding_Assessment.Interface
{
    public interface IAdOtimizer
    {

        string Optimize(JobRequest jobRequest);
    }
}
