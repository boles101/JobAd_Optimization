﻿using System.Security.Principal;

namespace NET_Developer_Intern_API_Coding_Assessment.Model
{
    public class OptimizedAdResponse
    {
        public string? OptimizedAd { get; set; }
        public OptimizedAdResponse(string OptimizedAdResponse)
        {
            OptimizedAd = OptimizedAdResponse;
        }

    }
}
